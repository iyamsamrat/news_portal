<?php
declare(strict_types=1);

/**
 * Global App Config
 * Adjust BASE_URL if your folder name differs.
 */

define('APP_NAME', 'News Portal');

// If project path is: http://localhost/news_portal/public/
// then BASE_URL should be: /news_portal/public
define('BASE_URL', '/news_portal/public');

// Database
define('DB_HOST', 'localhost');
define('DB_NAME', 'eastpol1_news_portal');
define('DB_USER', 'eastpol1_news_portal');
define('DB_PASS', 'LW}}[g*T8*^Bm9!-');          // XAMPP default is empty
define('DB_CHARSET', 'utf8mb4');

// Sessions
define('SESSION_NAME', 'np_session');

// Uploads (public path)
define('UPLOAD_PATH', __DIR__ . '/../../public/uploads');
define('UPLOAD_URL', BASE_URL . '/uploads');
// browser url

// Environment
define('APP_DEBUG', false); // set false on production
